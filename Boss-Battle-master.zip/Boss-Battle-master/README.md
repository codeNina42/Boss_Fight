# Boss Battle
Project files for our tutorial on how to create a boss battle using state machines in Unity.



Check out our [YouTube Channel](http://youtube.com/brackeys) for more tutorials.